from django.contrib import admin
from .models import PDFDocument,QueryResponse

admin.site.register(PDFDocument)
admin.site.register(QueryResponse)